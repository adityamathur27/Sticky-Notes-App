package com.example.aditya.stickynotesapp;

import static com.example.aditya.stickynotesapp.R.id.italicbutton;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RemoteViews;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText et;
    private Button increase,reduce,bold,underline,italic;
    private TextView tv;
    stickynote note = new stickynote();
    Float currentsize;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et = (EditText) findViewById(R.id.edittext);
        increase = (Button) findViewById(R.id.increase);
        reduce = (Button) findViewById(R.id.reduce);
        bold = (Button) findViewById(R.id.boldbutoon);
        underline = (Button) findViewById(R.id.underlinebutton);
        italic = (Button) findViewById(R.id.italicbutton);
        tv = (TextView) findViewById(R.id.textView);
        currentsize = et.getTextSize();
        tv.setText(""+currentsize);
        increase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv.setText(""+currentsize);
                currentsize++;
                et.setTextSize(currentsize);

            }
        });
        reduce.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv.setText(""+currentsize);
                currentsize--;
                et.setTextSize(currentsize);

            }
        });
        bold.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                underline.setTextColor(getResources().getColor(R.color.white));
                underline.setBackgroundColor(getResources().getColor(R.color.purple));
                if(et.getTypeface().isBold()){
                    et.setTypeface(Typeface.DEFAULT);
                    bold.setTextColor(getResources().getColor(R.color.white));
                    bold.setBackgroundColor(getResources().getColor(R.color.purple));
                }else{
                    bold.setTextColor(getResources().getColor(R.color.purple));
                    bold.setBackgroundColor(getResources().getColor(R.color.white));
                    et.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
                }

            }
        });
        underline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                italic.setTextColor(getResources().getColor(R.color.white));
                italic.setBackgroundColor(getResources().getColor(R.color.purple));
                if(et.getPaintFlags()==8){
                    underline.setTextColor(getResources().getColor(R.color.white));
                    underline.setBackgroundColor(getResources().getColor(R.color.purple));
                    et.setPaintFlags(et.getPaintFlags() & (Paint.UNDERLINE_TEXT_FLAG));
                }else{
                    underline.setTextColor(getResources().getColor(R.color.purple));
                    underline.setBackgroundColor(getResources().getColor(R.color.white));
                    et.setPaintFlags(Paint.UNDERLINE_TEXT_FLAG);
                }

            }
        });
        italic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bold.setTextColor(getResources().getColor(R.color.white));
                bold.setBackgroundColor(getResources().getColor(R.color.purple));
                if(et.getTypeface().isItalic()){
                    et.setTypeface(Typeface.DEFAULT);
                    italic.setTextColor(getResources().getColor(R.color.white));
                    italic.setBackgroundColor(getResources().getColor(R.color.purple));
                }else{
                    italic.setTextColor(getResources().getColor(R.color.purple));
                    italic.setBackgroundColor(getResources().getColor(R.color.white));
                    et.setTypeface(Typeface.defaultFromStyle(Typeface.ITALIC));
                }

            }
        });
    }
    public void saveButton(View view) {
        note.setStick(et.getText().toString(),this);
        UpdateWidget();
        Toast.makeText(this,"Note is Updated Success",Toast.LENGTH_SHORT).show();
    }
    private void UpdateWidget(){
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(this);
        RemoteViews remoteViews = new RemoteViews(this.getPackageName(),R.layout.widget_layout);
        ComponentName widget = new ComponentName(this,AppWidget.class);
        remoteViews.setTextViewText(R.id.widgetTextView,et.getText().toString());
        appWidgetManager.updateAppWidget(widget,remoteViews);


    }
}